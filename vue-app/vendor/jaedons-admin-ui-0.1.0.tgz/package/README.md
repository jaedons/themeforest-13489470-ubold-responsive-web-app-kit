# @jaedons/admin-ui

本地私有组件包，提供 UiSectionCard、UiStatCard、UiDataTable 及 DataRow、TableColumn 类型。
导入样式：`import '@jaedons/admin-ui/style.css'`。
Vue 和 Element Plus 是 peer dependencies。暂不发布 npm，使用 npm pack 生成的 tgz 安装。
完整 API 和使用示例见源项目 docs/API.md。
